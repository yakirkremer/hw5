c:
	echo c > c
